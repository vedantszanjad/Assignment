package com.yash.programfive;

public interface Employee {

	public void print();
}
