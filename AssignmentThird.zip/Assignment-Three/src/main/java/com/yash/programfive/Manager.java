package com.yash.programfive;

public class Manager implements Employee  {

	@Override
	public void print() {
		System.out.println("Hi I Am Manager");
		
	}
}
