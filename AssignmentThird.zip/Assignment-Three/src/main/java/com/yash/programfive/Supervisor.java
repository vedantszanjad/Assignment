package com.yash.programfive;

public class Supervisor implements Employee 
{

	@Override
	public void print() {
	
		System.out.println("Hello I Am Supervisor");
		
	}

}
