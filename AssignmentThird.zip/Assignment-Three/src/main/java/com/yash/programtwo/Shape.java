package com.yash.programtwo;

public abstract class Shape {

	public abstract void draw();

}
