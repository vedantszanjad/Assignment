package com.yash.programfour;

public class SetterMessage {

	String message = null;

	public void setMessage(String message) {
		this.message = message;
	}
	
	public void display()
	{
		System.out.println(" Message :"+ message);
	}
}
